function showAlert(message) {
    alert(message);
  }
  